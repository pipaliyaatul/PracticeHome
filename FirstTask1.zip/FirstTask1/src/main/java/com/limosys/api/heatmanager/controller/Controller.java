package com.limosys.api.heatmanager.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.connection.RedisServer;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.limosys.api.heatmanager.service.RedisService;


@RestController
public class Controller 
{
	
	
	
	@Autowired
	RedisService redis;@Override
	public String toString() 
	{
		// TODO Auto-generated method stub
		return super.toString();
	}
	
	
	@RequestMapping(method = { RequestMethod.GET, RequestMethod.POST,RequestMethod.PUT})
	public ResponseEntity<String> ping() throws Exception 
	{
		
		String value = redis.get();
		if (value == null) 
		{
			redis.set(value);
			return new ResponseEntity<>(HttpStatus.CREATED);
		} else {
			return new ResponseEntity<>(HttpStatus.OK);
		}
	}
	
	@RequestMapping(method = { RequestMethod.PUT })
	public String get(String value) throws Exception 
	{
		redis.set(value);
		return value;
	}

}

